"""
Event class for Hard Times: Ottawa.
Represents a game event with choices and requirements.
"""
import random
from typing import Dict, List, Optional, Any, Union

class Event:
    """Represents a game event."""

    # Event type constants
    TYPE_GENERAL = "general"
    TYPE_QUEST = "quest"
    TYPE_ENCOUNTER = "encounter"
    TYPE_WEATHER = "weather"
    TYPE_OPPORTUNITY = "opportunity"
    TYPE_CHAIN = "chain"
    
    # Stat-based event types
    TYPE_HEALTH_CRITICAL = "health_critical"
    TYPE_HUNGER_CRITICAL = "hunger_critical"
    TYPE_MENTAL_CRISIS = "mental_crisis"
    TYPE_EXHAUSTION = "exhaustion"
    TYPE_POLICE_ENCOUNTER = "police_encounter"

    def __init__(self, event_id, title, description, choices, requirements=None, type="general", chain_events=None):
        """Initialize an event.

        Args:
            event_id (str): Unique identifier for the event
            title (str): Event title
            description (str): Event description
            choices (list): List of possible choices and their outcomes
            requirements (dict): Requirements for this event to trigger (optional)
            type (str): Event type (general, quest, encounter, etc.)
            chain_events (list): Follow-up events in a chain (optional)
        """
        self.event_id = event_id
        self.title = title
        self.description = description
        self.choices = choices
        self.requirements = requirements or {}
        self.type = type
        self.chain_events = chain_events or []
        self.times_triggered = 0
        self.times_completed = 0
        self.last_outcome = None
        
    def meets_requirements(self, player, time_system, location=None):
        """Check if event requirements are met.
        
        Args:
            player: Player object
            time_system: TimeSystem object
            location: Current location (optional)
            
        Returns:
            bool: True if requirements are met
        """
        if not self.requirements:
            return True
            
        # Check each requirement
        for req_type, req_value in self.requirements.items():
            if req_type == 'health' and player.health < req_value:
                return False
            elif req_type == 'mental' and player.mental < req_value:
                return False
            elif req_type == 'money' and player.money < req_value:
                return False
            elif req_type == 'time_period':
                current_period = time_system.get_period()
                if current_period != req_value:
                    return False
            elif req_type == 'has_item' and not player.inventory.has_item(req_value):
                return False
            elif req_type == 'skill_level':
                skill, level = req_value.split(':')
                if player.get_skill_level(skill) < int(level):
                    return False
            elif req_type == 'location_type' and location and location.type != req_value:
                return False
            elif req_type == 'weather' and time_system.weather != req_value:
                return False
            elif req_type == 'faction_rep':
                faction, min_rep = req_value.split(':')
                if player.faction_reputation.get(faction, 0) < int(min_rep):
                    return False
                    
        return True
        
    def get_weighted_choices(self):
        """Get choices with weights for probability-based selection."""
        weighted = []
        for choice in self.choices:
            # Default weight is 1 if not specified
            weight = choice.get('weight', 1)
            weighted.append((choice, weight))
        return weighted
        
    def choose_random_with_weights(self):
        """Select a random choice based on weights."""
        weighted_choices = self.get_weighted_choices()
        total = sum(w for _, w in weighted_choices)
        r = random.uniform(0, total)
        upto = 0
        for choice, weight in weighted_choices:
            if upto + weight >= r:
                return choice
            upto += weight
        # Fallback to first choice if something goes wrong
        return self.choices[0]