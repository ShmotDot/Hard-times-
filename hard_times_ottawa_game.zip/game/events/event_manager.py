"""
EventManager class for Hard Times: Ottawa.
Manages game events, encounters, and their triggers.
"""
import random
import json
import os
from typing import Dict, List, Optional, Any, Union
from collections import defaultdict
from .event import Event
from .event_journal import EventJournal

class EventManager:
    """Manages game events and encounters."""

    def __init__(self, player, time_system):
        """Initialize the event manager.

        Args:
            player: Player object
            time_system: TimeSystem object
        """
        self.player = player
        self.time_system = time_system
        self.events = {}
        self.event_journal = EventJournal()
        self.event_cooldowns = {}
        self.event_chains = {}
        self.pending_chain_events = []
        self.event_categories = defaultdict(list)
        
        # Load events from data
        self.load_events()
    
    def load_events(self, file_path='data/events.json'):
        """Load events from JSON file.
        
        Args:
            file_path (str): Path to events data file
        """
        try:
            if not os.path.exists(file_path):
                print(f"Warning: Events file not found at {file_path}")
                # Create a minimal set of events for testing
                self._create_default_events()
                return
                
            with open(file_path, 'r') as f:
                events_data = json.load(f)
                
            for event_id, event_data in events_data.items():
                # Convert choice structure if needed
                choices = event_data.get('choices', [])
                # Standardize choice structure - we need to transform outcomes to effects
                # in the format the Event class expects
                normalized_choices = []
                for choice in choices:
                    # Copy basic choice data
                    normalized_choice = {
                        "text": choice.get("text", "Make a choice")
                    }
                    
                    # If there's an outcomes field, extract it as effects
                    if "outcomes" in choice:
                        outcomes = choice["outcomes"]
                        # Extract message as outcome if present
                        if "message" in outcomes:
                            normalized_choice["outcome"] = outcomes.pop("message", "")
                        # The rest become effects
                        normalized_choice["effects"] = outcomes
                    else:
                        # If already in correct format, keep as is
                        if "outcome" in choice:
                            normalized_choice["outcome"] = choice["outcome"]
                        if "effects" in choice:
                            normalized_choice["effects"] = choice["effects"]
                    
                    # Copy any other fields
                    for key, value in choice.items():
                        if key not in ["text", "outcomes"] and key not in normalized_choice:
                            normalized_choice[key] = value
                    
                    normalized_choices.append(normalized_choice)
                
                # Create the event with normalized choices
                # Use event_id from the data if present, otherwise use the dictionary key
                # Handle missing fields gracefully by providing defaults
                try:
                    event = Event(
                        event_id=event_id,  # Use the key from the dictionary as the event_id
                        title=event_data.get('title', f"Event {event_id}"),  # Provide fallback title
                        description=event_data.get('description', "An event occurs."),  # Fallback description
                        choices=normalized_choices,
                        requirements=event_data.get('requirements'),
                        type=event_data.get('type', 'general'),
                        chain_events=event_data.get('chain_events', [])
                    )
                except Exception as e:
                    print(f"Error creating event {event_id}: {e}")
                    continue  # Skip this event if it can't be created
                self.events[event.event_id] = event
                
                # Organize by category
                self.event_categories[event.type].append(event.event_id)
                
                # Set up any event chains
                if event.chain_events:
                    self.event_chains[event.event_id] = event.chain_events
        except Exception as e:
            print(f"Error loading events: {e}")
            self._create_default_events()
    
    def _create_default_events(self):
        """Create a minimal set of default events if data file is missing."""
        # Basic shelter event
        shelter_event = Event(
            event_id="shelter_basic",
            title="Finding Shelter",
            description="Night is approaching, and you need to find shelter. You spot an abandoned building and a small park nearby.",
            choices=[
                {
                    "text": "Try the abandoned building",
                    "outcome": "You find a relatively dry corner in the abandoned building. It's not comfortable, but it provides some protection.",
                    "effects": {"health": -5, "mental": -5, "sleep_quality": 0.5}
                },
                {
                    "text": "Sleep in the park",
                    "outcome": "You find a bench in the park. It's cold and exposed, but at least it feels safer than the abandoned building.",
                    "effects": {"health": -10, "mental": -8, "sleep_quality": 0.3}
                }
            ],
            type="general"
        )
        self.events[shelter_event.event_id] = shelter_event
        self.event_categories[shelter_event.type].append(shelter_event.event_id)
        
        # Food event
        food_event = Event(
            event_id="food_basic",
            title="Finding Food",
            description="Your stomach growls with hunger. You need to find something to eat.",
            choices=[
                {
                    "text": "Check nearby dumpsters",
                    "outcome": "You find some discarded but still edible food in a dumpster behind a restaurant.",
                    "effects": {"health": -2, "hunger": 30, "mental": -5}
                },
                {
                    "text": "Try to beg for food or money",
                    "outcome": "After a few attempts, someone gives you a sandwich and an apple.",
                    "effects": {"hunger": 40, "mental": -3, "social_status": -2}
                }
            ],
            type="general"
        )
        self.events[food_event.event_id] = food_event
        self.event_categories[food_event.type].append(food_event.event_id)
    
    def get_random_event(self, location=None, event_type=None):
        """Get a random event that meets current requirements.
        
        Args:
            location: Current location (optional)
            event_type (str): Specific event type to filter for (optional)
            
        Returns:
            Event or None: A random eligible event, or None if none available
        """
        # Check for critical stat-based events first
        critical_event = self._check_critical_stats()
        if critical_event:
            return critical_event

        # First check for any pending chain events
        if self.pending_chain_events:
            event_id = self.pending_chain_events.pop(0)
            event = self.events.get(event_id)
            if event and event.meets_requirements(self.player, self.time_system, location):
                return event
        
        # Filter events by type if specified
        eligible_ids = []
        if event_type:
            eligible_ids = self.event_categories.get(event_type, [])
        else:
            # Get all events
            for category in self.event_categories.values():
                eligible_ids.extend(category)
        
        # Shuffle to randomize selection
        random.shuffle(eligible_ids)
        
        # Find first eligible event
        for event_id in eligible_ids:
            # Skip events on cooldown
            if event_id in self.event_cooldowns:
                continue
                
            event = self.events.get(event_id)
            if event and event.meets_requirements(self.player, self.time_system, location):
                return event
                
        return None
    def _check_critical_stats(self):
        """Check for events that should trigger based on player stats."""
        # Critical health event
        if self.player.health < 20:
            return self._get_stat_based_event("health_critical")
            
        # Extreme hunger event
        if self.player.satiety < 15:
            return self._get_stat_based_event("hunger_critical")
            
        # Mental breakdown risk
        if self.player.mental < 25:
            return self._get_stat_based_event("mental_crisis")
            
        # Extreme fatigue
        if self.player.energy < 10:
            return self._get_stat_based_event("exhaustion")
            
        # Police attention
        if self.player.heat > 80:
            return self._get_stat_based_event("police_encounter")
            
        return None
        
    def _get_stat_based_event(self, event_type):
        """Get an appropriate event based on the critical stat condition."""
        eligible_events = [
            event for event in self.events.values()
            if event.type == event_type and event.event_id not in self.event_cooldowns
        ]
        if eligible_events:
            return random.choice(eligible_events)
        return None
    
    def process_event_outcome(self, event, choice_index):
        """Process the outcome of an event choice.
        
        Args:
            event (Event): The current event
            choice_index (int): Index of the chosen choice
            
        Returns:
            dict: Outcome information including effects
        """
        choice = event.choices[choice_index]
        outcome = choice.get('outcome', 'Nothing happens.')
        effects = choice.get('effects', {})
        
        # Apply effects to player
        self._apply_effects(effects)
        
        # Set cooldown on this event
        cooldown = choice.get('cooldown', 12)  # Default 12 hours
        self.event_cooldowns[event.event_id] = cooldown
        
        # Record in journal
        self.event_journal.add_entry(event, choice, effects, self.time_system)
        
        # Check for chain events
        if event.event_id in self.event_chains and choice.get('trigger_chain', False):
            self.pending_chain_events.extend(self.event_chains[event.event_id])
        
        # Update event counters
        event.times_completed += 1
        event.last_outcome = outcome
        
        return {
            'text': outcome,
            'effects': effects
        }
    
    def _apply_effects(self, effects):
        """Apply event effects to the player.
        
        Args:
            effects (dict): Dictionary of effects and values
        """
        for stat, value in effects.items():
            if stat == 'health':
                self.player.health = max(0, min(100, self.player.health + value))
            elif stat == 'mental':
                self.player.mental = max(0, min(100, self.player.mental + value))
            elif stat == 'hunger':
                self.player.satiety = max(0, min(100, self.player.satiety + value))
            elif stat == 'energy':
                self.player.energy = max(0, min(100, self.player.energy + value))
            elif stat == 'money':
                self.player.money += value
            elif stat == 'heat':
                self.player.increase_heat(value) if value > 0 else self.player.decrease_heat(-value)
            elif stat == 'faction_rep':
                faction, rep_value = value.split(':')
                self.player.improve_reputation(faction, int(rep_value))
            elif stat == 'item':
                item_name, quantity = value.split(':')
                self.player.inventory.add_item(item_name, int(quantity))
            elif stat == 'skill':
                skill_name, points = value.split(':')
                self.player.improve_skill(skill_name, int(points))
    
    def update(self):
        """Update event system state - called once per game cycle."""
        # Decrease cooldowns
        for event_id in list(self.event_cooldowns.keys()):
            self.event_cooldowns[event_id] -= 1
            if self.event_cooldowns[event_id] <= 0:
                del self.event_cooldowns[event_id]
                
        # Check for time-based event triggers
        period = self.time_system.get_period()
        if period == 'night' and random.random() < 0.2:
            # Higher chance of danger at night
            self.trigger_event(event_type=Event.TYPE_ENCOUNTER)
    
    def trigger_event(self, event_id=None, event_type=None):
        """Trigger a specific event or a random event of given type.
        
        Args:
            event_id (str): Specific event ID to trigger (optional)
            event_type (str): Event type to trigger (optional)
            
        Returns:
            Event or None: The triggered event, or None if none available
        """
        if event_id and event_id in self.events:
            event = self.events[event_id]
            event.times_triggered += 1
            return event
            
        event = self.get_random_event(event_type=event_type)
        if event:
            event.times_triggered += 1
            
        return event
        
    def process_event(self, event, location):
        """Process the event and handle player choice.

        Args:
            event (Event): The event to process
            location (Location): Current location
        """
        import logging
        from game.ui import UI
        ui = UI()
        
        # Check if event is valid
        if not event:
            logging.error("Tried to process an invalid event")
            ui.display_error("Error: Tried to process an invalid event")
            ui.display_text("You continue on your way...")
            return
            
        # Validate event has required attributes
        if not hasattr(event, 'title') or not hasattr(event, 'description') or not hasattr(event, 'choices'):
            logging.error(f"Event is missing required attributes: {str(event)}")
            ui.display_error("Error: Event is malformed")
            ui.display_text("You encounter something unusual but press on...")
            return

        # Display event
        try:
            ui.display_title(event.title)
            ui.display_text(event.description)
            ui.display_divider()
        except Exception as e:
            logging.error(f"Error displaying event: {str(e)}")
            ui.display_error(f"Error displaying event: {str(e)}")
            ui.display_text("Something strange happens, but you continue on...")
            return
            
        # Validate choices
        if not event.choices or not isinstance(event.choices, list):
            logging.error(f"Event has invalid choices format: {str(event.choices)}")
            ui.display_error("This situation offers no clear options.")
            ui.display_text("You decide to move on...")
            return

        # Display choices
        ui.display_title("Options")
        for i, choice in enumerate(event.choices, 1):
            meets_reqs = True
            try:
                # Check if choice has requirements
                if "requirements" in choice and isinstance(choice["requirements"], dict):
                    reqs = choice["requirements"]

                    # Check inventory requirements
                    if "inventory" in reqs:
                        for item, quantity in reqs["inventory"].items():
                            if not self.player.has_item(item, quantity):
                                meets_reqs = False

                    # Check skill requirements
                    if "skills" in reqs:
                        for skill, level in reqs["skills"].items():
                            if hasattr(self.player, 'skills') and isinstance(self.player.skills, dict):
                                if self.player.skills.get(skill, 0) < level:
                                    meets_reqs = False
                            elif hasattr(self.player, 'get_skill_level'):
                                if self.player.get_skill_level(skill) < level:
                                    meets_reqs = False

                    # Check reputation requirements
                    if "reputation" in reqs:
                        for group, level in reqs["reputation"].items():
                            if self.player.reputation.get(group, 0) < level:
                                meets_reqs = False

                    # Check stat requirements
                    if "player_stats" in reqs:
                        for stat, values in reqs["player_stats"].items():
                            if "min" in values and getattr(self.player, stat, 0) < values["min"]:
                                meets_reqs = False
                            if "max" in values and getattr(self.player, stat, 100) > values["max"]:
                                meets_reqs = False

                # Display choice (with indicator if requirements aren't met)
                if meets_reqs:
                    ui.display_text(f"{i}. {choice['text']}")
                else:
                    ui.display_text(f"{i}. {choice['text']} (requirements not met)", color="red")
                    
            except Exception as e:
                logging.error(f"Error processing choice: {str(e)}")
                # Fallback: display the choice without requirement checking
                ui.display_text(f"{i}. {choice.get('text', 'Unknown option')}")

        # Get player choice
        from game.utils import safe_input
        while True:
            try:
                choice_input = safe_input("\nWhat do you do? ")
                if not choice_input:  # Handle empty input gracefully
                    ui.display_error("Please make a choice.")
                    continue
                    
                choice_num = int(choice_input)
                if 1 <= choice_num <= len(event.choices):
                    choice = event.choices[choice_num - 1]

                    # Check requirements again
                    meets_reqs = True
                    if "requirements" in choice:
                        reqs = choice["requirements"]

                        # Check inventory requirements
                        if "inventory" in reqs:
                            for item, quantity in reqs["inventory"].items():
                                if not self.player.has_item(item, quantity):
                                    meets_reqs = False

                        # Check skill requirements
                        if "skills" in reqs:
                            for skill, level in reqs["skills"].items():
                                if hasattr(self.player, 'skills') and isinstance(self.player.skills, dict):
                                    if self.player.skills.get(skill, 0) < level:
                                        meets_reqs = False
                                elif hasattr(self.player, 'get_skill_level'):
                                    if self.player.get_skill_level(skill) < level:
                                        meets_reqs = False

                        # Check reputation requirements
                        if "reputation" in reqs:
                            for group, level in reqs["reputation"].items():
                                if self.player.reputation.get(group, 0) < level:
                                    meets_reqs = False

                        # Check stat requirements
                        if "player_stats" in reqs:
                            for stat, values in reqs["player_stats"].items():
                                if "min" in values and getattr(self.player, stat, 0) < values["min"]:
                                    meets_reqs = False
                                if "max" in values and getattr(self.player, stat, 100) > values["max"]:
                                    meets_reqs = False

                    if meets_reqs:
                        break
                    else:
                        ui.display_error("You don't meet the requirements for this choice.")
                else:
                    ui.display_error("Please enter a valid choice number.")
            except ValueError:
                ui.display_error("Please enter a number.")

        # Process outcomes
        ui.display_divider()
        
        # Process the outcome using our dedicated method
        outcome = self.process_event_outcome(event, choice_num - 1)
        
        # Display outcome message
        if 'text' in outcome:
            ui.display_text(outcome['text'])
        
        # Check for chain events
        if event.chain_events and choice.get('trigger_chain', False):
            ui.display_text("\nYour decision leads to further developments...")
            for chain_event_id in event.chain_events:
                chain_event = self.events.get(chain_event_id)
                if chain_event:
                    ui.display_divider()
                    ui.display_text("Later...")
                    self.process_event(chain_event, location)
                    
        # Update event journal
        self.event_journal.add_entry(event, choice, outcome.get('effects', {}), self.time_system)
        
        return outcome