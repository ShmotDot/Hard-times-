"""
EventJournal class for Hard Times: Ottawa.
Tracks event history and provides player impact analysis.
"""
from datetime import datetime
from collections import defaultdict

class EventJournal:
    """Tracks event history and analyzes patterns."""
    
    def __init__(self):
        """Initialize an empty event journal."""
        self.entries = []
        self.impact_analysis = defaultdict(list)
        self.recurring_patterns = defaultdict(int)

    def add_entry(self, event, choice, impacts, time_system):
        """Record an event and its impacts.
        
        Args:
            event: The Event object
            choice: The selected choice dictionary
            impacts: Dictionary of stat impacts
            time_system: TimeSystem object for date/time context
        """
        entry = {
            'timestamp': datetime.now(),
            'day': time_system.get_day(),
            'event_id': event.event_id,
            'title': event.title,
            'choice': choice['text'],
            'impacts': impacts,
            'period': time_system.get_period(),
            'weather': time_system.weather
        }
        self.entries.append(entry)
        self._analyze_impact(impacts)

    def _analyze_impact(self, impacts):
        """Analyze the impacts of choices on player wellbeing.
        
        Args:
            impacts: Dictionary of stat impacts
        """
        for stat, value in impacts.items():
            if isinstance(value, (int, float)):
                self.impact_analysis[stat].append(value)

    def get_insights(self):
        """Generate insights from recorded events.
        
        Returns:
            list: List of insight strings
        """
        insights = []

        # Analyze patterns
        for stat, values in self.impact_analysis.items():
            if len(values) >= 3:
                avg_impact = sum(values[-3:]) / 3
                if avg_impact < -10:
                    insights.append(f"You're consistently losing {stat} in recent events. Consider changing your approach.")
                elif avg_impact > 10:
                    insights.append(f"Your choices are effectively improving your {stat}.")

        # Look for recurring event types
        event_types = {}
        for entry in self.entries[-10:]:  # Look at last 10 events
            event_id = entry['event_id']
            event_types[event_id] = event_types.get(event_id, 0) + 1
        
        # Check for events happening too frequently
        for event_id, count in event_types.items():
            if count >= 3:  # 3+ occurrences in last 10 events
                if any(entry['event_id'] == event_id for entry in self.entries[-3:]):  # In last 3 events
                    insights.append(f"'{next((e['title'] for e in self.entries if e['event_id'] == event_id), 'An event')}' seems to be happening frequently.")
        
        return insights

    def get_entry_by_day(self, day):
        """Get all entries for a specific day.
        
        Args:
            day: Game day number
            
        Returns:
            list: Entries from the specified day
        """
        return [entry for entry in self.entries if entry['day'] == day]

    def get_major_events(self):
        """Get list of significant events with large impacts.
        
        Returns:
            list: Significant events
        """
        major_events = []
        for entry in self.entries:
            # Check if any impact values are large
            has_major_impact = any(abs(val) >= 15 for val in entry['impacts'].values() if isinstance(val, (int, float)))
            if has_major_impact:
                major_events.append(entry)
        return major_events