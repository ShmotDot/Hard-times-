"""
Map visualization module for Hard Times Ottawa.
Provides text-based visualization of the game world map.
"""
import math

class MapVisuals:
    """Handles generation of a visual map representation."""
    
    def __init__(self, use_colors=True):
        """Initialize the map visualization system.
        
        Args:
            use_colors (bool): Whether to use ANSI color codes
        """
        self.use_colors = use_colors
        
        # Define color codes for map visuals
        self.colors = {
            "reset": "\033[0m",
            "bold": "\033[1m",
            "green": "\033[92m",
            "blue": "\033[94m",
            "red": "\033[91m",
            "yellow": "\033[93m",
            "magenta": "\033[95m",
            "cyan": "\033[96m",
            "white": "\033[97m",
            "gray": "\033[90m"
        }
        
        # Map symbols
        self.symbols = {
            "player": "P",
            "shelter": "S",
            "food": "F",
            "hospital": "H",
            "service": "?",
            "park": "#",
            "landmark": "L",
            "shop": "$",
            "road": "·",
            "water": "~",
            "building": "■",
            "wall": "█",
            "empty": " "
        }
        
        # Define map dimensions
        self.map_width = 80
        self.map_height = 20
    
    def generate_map(self, player_location, all_locations):
        """Generate a text-based map showing locations and player position.
        
        Args:
            player_location: Current player location object
            all_locations: List of all available locations
            
        Returns:
            str: Text-based map
        """
        # Create empty map grid
        grid = [[self.symbols["empty"] for _ in range(self.map_width)] for _ in range(self.map_height)]
        
        # Add location markers
        for location in all_locations:
            if hasattr(location, 'map_x') and hasattr(location, 'map_y'):
                x = min(max(int(location.map_x * self.map_width), 0), self.map_width - 1)
                y = min(max(int(location.map_y * self.map_height), 0), self.map_height - 1)
                
                # Choose symbol based on location type
                symbol = self._get_location_symbol(location)
                
                # Place in grid
                grid[y][x] = symbol
        
        # Add player marker at current location
        if hasattr(player_location, 'map_x') and hasattr(player_location, 'map_y'):
            player_x = min(max(int(player_location.map_x * self.map_width), 0), self.map_width - 1)
            player_y = min(max(int(player_location.map_y * self.map_height), 0), self.map_height - 1)
            grid[player_y][player_x] = self.symbols["player"]
        
        # Convert grid to text representation
        map_text = ""
        for row in grid:
            map_text += "".join(row) + "\n"
        
        # Add legend
        legend = self._generate_legend()
        
        return map_text + "\n" + legend
    
    def _get_location_symbol(self, location):
        """Get appropriate symbol for a location type.
        
        Args:
            location: Location object
            
        Returns:
            str: Symbol representing the location
        """
        if hasattr(location, 'type'):
            location_type = location.type.lower()
            
            if "shelter" in location_type:
                return self.symbols["shelter"]
            elif "food" in location_type or "restaurant" in location_type:
                return self.symbols["food"]
            elif "hospital" in location_type or "clinic" in location_type:
                return self.symbols["hospital"]
            elif "service" in location_type:
                return self.symbols["service"]
            elif "park" in location_type:
                return self.symbols["park"]
            elif "landmark" in location_type:
                return self.symbols["landmark"]
            elif "shop" in location_type or "store" in location_type:
                return self.symbols["shop"]
            else:
                return self.symbols["building"]
        
        return self.symbols["building"]
    
    def _generate_legend(self):
        """Generate a legend for the map symbols.
        
        Returns:
            str: Text-based legend
        """
        legend = "Legend: "
        legend_items = [
            ("P", "You"),
            ("S", "Shelter"),
            ("F", "Food"),
            ("H", "Hospital"),
            ("?", "Services"),
            ("$", "Shop"),
            ("#", "Park"),
            ("■", "Building")
        ]
        
        for symbol, description in legend_items:
            if self.use_colors:
                color = self._get_color_for_symbol(symbol)
                legend += f"{color}{symbol}{self.colors['reset']}={description} "
            else:
                legend += f"{symbol}={description} "
        
        return legend
    
    def _get_color_for_symbol(self, symbol):
        """Get appropriate color for a symbol.
        
        Args:
            symbol: Map symbol
            
        Returns:
            str: ANSI color code
        """
        color_mapping = {
            "P": self.colors["cyan"] + self.colors["bold"],
            "S": self.colors["green"],
            "F": self.colors["yellow"],
            "H": self.colors["red"],
            "?": self.colors["blue"],
            "$": self.colors["magenta"],
            "#": self.colors["green"],
            "■": self.colors["gray"],
            "~": self.colors["blue"],
            "·": self.colors["gray"]
        }
        
        return color_mapping.get(symbol, self.colors["white"])
    
    def get_location_info(self, location):
        """Generate detailed location info display.
        
        Args:
            location: Location object
            
        Returns:
            str: Formatted location info
        """
        if not location:
            return "Unknown location"
        
        info = []
        
        # Location name and type
        if self.use_colors:
            info.append(f"{self.colors['bold']}{self.colors['cyan']}{location.name}{self.colors['reset']}")
            if hasattr(location, 'type'):
                info.append(f"Type: {location.type}")
        else:
            info.append(f"{location.name}")
            if hasattr(location, 'type'):
                info.append(f"Type: {location.type}")
        
        # Location description
        if hasattr(location, 'description'):
            info.append(f"\n{location.description}")
        
        # Available services
        if hasattr(location, 'services') and location.services:
            if self.use_colors:
                info.append(f"\n{self.colors['bold']}Available Services:{self.colors['reset']}")
            else:
                info.append("\nAvailable Services:")
                
            for service in location.services:
                info.append(f"• {service}")
        
        # Safety rating
        if hasattr(location, 'safety_rating'):
            safety = location.safety_rating
            if self.use_colors:
                color = self.colors["green"] if safety >= 7 else self.colors["yellow"] if safety >= 4 else self.colors["red"]
                info.append(f"\nSafety Rating: {color}{safety}/10{self.colors['reset']}")
            else:
                info.append(f"\nSafety Rating: {safety}/10")
        
        return "\n".join(info)
    
    def get_travel_options(self, current_location, available_destinations):
        """Generate a visual display of travel options.
        
        Args:
            current_location: Current location object
            available_destinations: List of available destination objects
            
        Returns:
            str: Formatted travel options
        """
        options = []
        
        if self.use_colors:
            options.append(f"{self.colors['bold']}Travel Options from {current_location.name}{self.colors['reset']}")
        else:
            options.append(f"Travel Options from {current_location.name}")
        
        for i, destination in enumerate(available_destinations, 1):
            # Calculate distance (if coordinates are available)
            distance_str = ""
            if (hasattr(current_location, 'map_x') and hasattr(current_location, 'map_y') and
                hasattr(destination, 'map_x') and hasattr(destination, 'map_y')):
                
                dx = (destination.map_x - current_location.map_x) * 100
                dy = (destination.map_y - current_location.map_y) * 100
                distance = math.sqrt(dx*dx + dy*dy)
                
                # Convert abstract distance to something meaningful
                if distance < 20:
                    distance_str = " (Nearby)"
                elif distance < 50:
                    distance_str = " (Medium distance)"
                else:
                    distance_str = " (Far away)"
            
            # Show any special conditions or risks
            condition_str = ""
            if hasattr(destination, 'travel_danger') and destination.travel_danger > 0:
                danger = destination.travel_danger
                if danger > 7:
                    condition_str = " [DANGEROUS ROUTE]"
                elif danger > 3:
                    condition_str = " [Risky travel]"
            
            # Format the option
            if self.use_colors:
                name_color = self.colors['white']
                if hasattr(destination, 'travel_danger'):
                    name_color = (self.colors['red'] if destination.travel_danger > 7 else
                                self.colors['yellow'] if destination.travel_danger > 3 else
                                self.colors['green'])
                
                options.append(f"{i}. {name_color}{destination.name}{self.colors['reset']}{distance_str}{condition_str}")
            else:
                options.append(f"{i}. {destination.name}{distance_str}{condition_str}")
            
            # Add brief description if available
            if hasattr(destination, 'brief_description'):
                options.append(f"   {destination.brief_description}")
        
        return "\n".join(options)