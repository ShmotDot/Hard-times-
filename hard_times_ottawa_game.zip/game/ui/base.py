"""
Base UI module for Hard Times: Ottawa.
Handles text-based interface, formatting, and display functions.
"""
import os
import sys
import time

class UI:
    """Handles display and formatting of game text."""

    def __init__(self):
        """Initialize the UI with default settings."""
        # Check if terminal actually supports ANSI color codes
        self.use_colors = hasattr(sys.stdout, 'isatty') and sys.stdout.isatty()

        # Maximum size for feedback log to prevent memory leaks
        self.MAX_LOG_ENTRIES = 10
        self._cleanup_feedback_log()

        # Define ANSI color codes
        self.colors = {
            "reset": "\033[0m",
            "bold": "\033[1m",
            "underline": "\033[4m",
            "red": "\033[91m",
            "green": "\033[92m",
            "yellow": "\033[93m",
            "blue": "\033[94m",
            "magenta": "\033[95m",
            "cyan": "\033[96m",
            "white": "\033[97m",
            "gray": "\033[90m"
        }

        # Terminal width (default to 80 for consistency)
        self.width = 80  # Fixed width to avoid issues with terminal size detection
        
        # Store feedback and stats
        self.feedback_log = []  # Store recent feedback messages
        self.previous_stats = {}  # Store previous stat values
        self.MAX_LOG_ENTRIES = 5  # Number of recent messages to show

    def display_title(self, title):
        """Display a formatted title with border.

        Args:
            title (str): The title to display
        """
        width = min(self.width, 80)
        padding = (width - len(title) - 4) // 2
        if self.use_colors:
            border = f"{self.colors['cyan']}{'═' * width}{self.colors['reset']}"
            print(f"\n{border}")
            print(f"{self.colors['cyan']}║{' ' * padding}{self.colors['bold']}{self.colors['white']}{title}{' ' * (width - len(title) - padding - 2)}║{self.colors['reset']}")
            print(border)
        else:
            border = '═' * width
            print(f"\n{border}")
            print(f"║{' ' * padding}{title}{' ' * (width - len(title) - padding - 2)}║")
            print(border)

    def display_subtitle(self, subtitle):
        """Display a formatted subtitle.

        Args:
            subtitle (str): The subtitle to display
        """
        if self.use_colors:
            print(f"\n{self.colors['bold']}{self.colors['yellow']}{subtitle}{self.colors['reset']}")
        else:
            print(f"\n{subtitle}")

    def display_text(self, text, color=None):
        """Display text, optionally with color.

        Args:
            text (str): The text to display
            color (str, optional): Color name to use
        """
        if self.use_colors and color is not None and color in self.colors:
            print(f"{self.colors[color]}{text}{self.colors['reset']}")
        else:
            print(text)

    def display_divider(self):
        """Display a horizontal divider line."""
        line_width = min(self.width, 80)  # Cap at 80 chars
        print("\n" + "-" * line_width)

    def _animate_loading(self, message="Loading", duration=1.0):
        """Display an animated loading message.

        Args:
            message (str): Base message to display
            duration (float): Animation duration in seconds
        """
        frames = [".  ", ".. ", "..."]
        for _ in range(int(duration * 3)):
            for frame in frames:
                sys.stdout.write(f"\r{message}{frame}")
                sys.stdout.flush()
                time.sleep(0.1)
        print()

    def _get_status_color(self, value):
        """Get color based on status value with smooth transitions.

        Args:
            value (int): Status value 0-100
        """
        if value > 60:
            return self.colors["green"]
        elif value > 30:
            return self.colors["yellow"]
        return self.colors["red"]

    def _cleanup_feedback_log(self):
        """Clean up old feedback messages to prevent memory leaks."""
        if hasattr(self, 'feedback_log'):
            while len(self.feedback_log) > self.MAX_LOG_ENTRIES:
                self.feedback_log.pop(0)
        else:
            self.feedback_log = []

    def add_feedback(self, message, category="info"):
        """Add a feedback message to the log.
        
        Args:
            message (str): The feedback message
            category (str): Message category (info, warning, success)
        """
        if not hasattr(self, 'feedback_log'):
            self.feedback_log = []
        self.feedback_log.append({"message": message, "category": category})
        self._cleanup_feedback_log()

    def clear_screen(self):
        """Clear the terminal screen."""
        if os.name == 'nt':  # Windows
            os.system('cls')
        else:  # Mac and Linux
            os.system('clear')

    def progress_bar(self, value, max_value, title="Progress", width=30, animate=False):
        """Display a progress bar.
        
        Args:
            value (int): Current value
            max_value (int): Maximum value
            title (str): Bar title
            width (int): Width of bar
            animate (bool): Whether to animate the bar
        """
        filled_width = int(width * (value / max_value))
        percent = value / max_value * 100
        
        if self.use_colors:
            if percent >= 75:
                color = self.colors['green']
            elif percent >= 50:
                color = self.colors['yellow']
            else:
                color = self.colors['white']
            
            bar = f"{color}{'█' * filled_width}{'░' * (width - filled_width)}{self.colors['reset']}"
        else:
            bar = f"{'#' * filled_width}{'-' * (width - filled_width)}"
        
        print(f"{title}: [{bar}] {percent:.1f}%")

    def display_inventory(self, inventory, money=0.0):
        """Display the player's inventory.
        
        Args:
            inventory: Player's inventory object
            money (float): Player's money
        """
        self.display_subtitle("Inventory")
        
        if money > 0:
            print(f"Money: ${money:.2f}")
        
        if not inventory.items:
            print("Your inventory is empty.")
            return
        
        categories = {}
        for item in inventory.items:
            cat = item.category if hasattr(item, 'category') else "Miscellaneous"
            if cat not in categories:
                categories[cat] = []
            categories[cat].append(item)
        
        for category, items in categories.items():
            print(f"\n{category.title()}:")
            for i, item in enumerate(items, 1):
                name = item.name
                quality = f" ({item.quality})" if hasattr(item, 'quality') else ""
                print(f"{i}. {name}{quality}")

    def display_help(self):
        """Display help information."""
        self.clear_screen()
        self.display_title("HELP MENU")
        
        help_sections = [
            {
                "title": "Basic Controls",
                "content": [
                    "Enter the number of your choice and press Enter.",
                    "Type 'q' or '8' to quit the game.",
                    "Type 'h' or '7' for help."
                ]
            },
            {
                "title": "Survival Tips",
                "content": [
                    "Keep your health above 0 or you'll lose.",
                    "Find food regularly to avoid starvation.",
                    "Rest to regain energy.",
                    "Find shelter during harsh weather."
                ]
            },
            {
                "title": "Game Mechanics",
                "content": [
                    "Weather affects your health and energy.",
                    "Time passes as you perform actions.",
                    "Different locations offer different opportunities."
                ]
            }
        ]
        
        for section in help_sections:
            self.display_subtitle(section["title"])
            for line in section["content"]:
                print(f"• {line}")
        
        print("\nPress Enter to return to the game...")
        input()

    def display_location(self, location):
        """Display information about the current location.
        
        Args:
            location: The current location object
        """
        self.display_subtitle(f"Location: {location.name}")
        print(location.description)
        
        if hasattr(location, 'services') and location.services:
            print("\nAvailable Services:")
            for service in location.services:
                print(f"• {service}")
        
        if hasattr(location, 'features') and location.features:
            print("\nLocation Features:")
            for feature in location.features:
                print(f"• {feature}")

    def display_status(self, player, time_system, show_daily_summary=False):
        """Display the player's status and game time with enhanced visuals.
        
        Args:
            player (Player): The player object
            time_system (TimeSystem): The time system object
            show_daily_summary (bool): Whether to show the daily summary
        """
        self.clear_screen()
        self._animate_loading("Updating status", 0.3)
        
        # Import here to avoid circular imports
        from game.weather_visuals import WeatherVisuals

        # Initialize weather visuals
        weather_visuals = WeatherVisuals(self.use_colors)

        # Create utility function for bars
        def create_bar(value, max_value=100, width=20, reverse=False):
            """Create a visual progress bar with color coding."""
            filled = int((value / max_value) * width)
            if self.use_colors:
                if reverse:
                    # For stats where higher is worse (e.g., hunger)
                    if value < 30:
                        color = self.colors['green']
                    elif value < 70:
                        color = self.colors['yellow']
                    else:
                        color = self.colors['red']
                else:
                    # For stats where higher is better (e.g., health)
                    if value > 60:
                        color = self.colors['green']
                    elif value > 30:
                        color = self.colors['yellow']
                    else:
                        color = self.colors['red']

                # Use different fill characters for better visual distinction
                return f"{color}{'█' * filled}{'░' * (width - filled)}{self.colors['reset']}"
            else:
                return f"{'#' * filled}{'-' * (width - filled)}"

        # Get weather effects
        weather_effects = time_system.get_weather_effects()
        weather_type = time_system.weather
        temperature = time_system.temperature
        is_harsh = time_system.is_harsh_weather()

        # Create a more decorative header with day count and time
        day_count = time_system.get_day()
        time_str = time_system.get_time_string()
        period = time_system.get_period().title()

        # Create a fancy day/time header
        if self.use_colors:
            day_header = f"{self.colors['cyan']}╔═══════════════════════════════════════════════════════╗{self.colors['reset']}"
            day_title = f"{self.colors['cyan']}║ {self.colors['bold']}{self.colors['white']}Day {day_count} | {time_str} | {period}{' ' * (40 - len(str(day_count)) - len(time_str) - len(period))} ║{self.colors['reset']}"
            day_footer = f"{self.colors['cyan']}╚═══════════════════════════════════════════════════════╝{self.colors['reset']}"
            print(f"\n{day_header}\n{day_title}\n{day_footer}")
        else:
            print(f"\n=== Day {day_count} | {time_str} | {period} ===")

        # Display dynamic weather banner with cool visuals
        print(weather_visuals.get_weather_banner(weather_type, temperature, is_harsh))
        
        # Show daily summary if requested
        if show_daily_summary:
            # Import here to avoid circular imports
            from game.daily_summary import DailySummary
            daily_summary = DailySummary(self)
            daily_summary.display_summary(player, time_system)

        # Display temperature bar with gradient
        print(weather_visuals.get_temperature_bar(temperature))

        # Display key weather effects with visual indicators in a more compact format
        effects_list = []
        for effect_name, effect_value in weather_effects.items():
            if effect_name not in ['description', 'event_modifiers']:
                effects_list.append(weather_visuals.get_weather_effect_indicator(effect_name, effect_value))

        if effects_list:
            if self.use_colors:
                print(f"\n{self.colors['bold']}Weather Effects:{self.colors['reset']} " + " | ".join(effects_list))
            else:
                print(f"\nWeather Effects: " + " | ".join(effects_list))

        # Create a fancy status panel with visual bars
        if self.use_colors:
            print(f"\n{self.colors['cyan']}╔═══════════════════════════════════════════════════════╗{self.colors['reset']}")
            print(f"{self.colors['cyan']}║ {self.colors['bold']}{self.colors['white']}STATUS{' ' * 45}║{self.colors['reset']}")
            print(f"{self.colors['cyan']}╠═══════════════════════════════════════════════════════╣{self.colors['reset']}")
        else:
            print("\n=== STATUS ===")

        # Display status bars with icons and values
        bar_width = 25

        # Health with heart icon
        health_bar = create_bar(player.health, 100, bar_width)
        health_icon = "♥" if self.use_colors else "HP"
        health_color = "green" if player.health > 60 else "yellow" if player.health > 30 else "red"
        if self.use_colors:
            print(f"{self.colors['cyan']}║ {self.colors['bold']}{self.colors[health_color]}{health_icon}{self.colors['reset']} Health:    {health_bar} {player.health:3}/100 {self.colors['cyan']}║{self.colors['reset']}")
        else:
            print(f"{health_icon} Health:    {health_bar} {player.health:3}/100")

        # Satiety/Fullness with food icon (higher is better)
        satiety_bar = create_bar(player.satiety, 100, bar_width)
        satiety_icon = "🍽" if self.use_colors else "ST"
        satiety_color = "green" if player.satiety > 60 else "yellow" if player.satiety > 30 else "red"
        if self.use_colors:
            print(f"{self.colors['cyan']}║ {self.colors['bold']}{self.colors[satiety_color]}{satiety_icon}{self.colors['reset']} Satiety:   {satiety_bar} {player.satiety:3}/100 {self.colors['cyan']}║{self.colors['reset']}")
        else:
            print(f"{satiety_icon} Satiety:   {satiety_bar} {player.satiety:3}/100")

        # Energy with lightning bolt icon
        energy_bar = create_bar(player.energy, 100, bar_width)
        energy_icon = "⚡" if self.use_colors else "EN"
        energy_color = "green" if player.energy > 60 else "yellow" if player.energy > 30 else "red"
        if self.use_colors:
            print(f"{self.colors['cyan']}║ {self.colors['bold']}{self.colors[energy_color]}{energy_icon}{self.colors['reset']} Energy:    {energy_bar} {player.energy:3}/100 {self.colors['cyan']}║{self.colors['reset']}")
        else:
            print(f"{energy_icon} Energy:    {energy_bar} {player.energy:3}/100")

        # Mental with brain icon
        mental_bar = create_bar(player.mental, 100, bar_width)
        mental_icon = "🧠" if self.use_colors else "MT"
        mental_color = "green" if player.mental > 60 else "yellow" if player.mental > 30 else "red"
        if self.use_colors:
            print(f"{self.colors['cyan']}║ {self.colors['bold']}{self.colors[mental_color]}{mental_icon}{self.colors['reset']} Mental:    {mental_bar} {player.mental:3}/100 {self.colors['cyan']}║{self.colors['reset']}")
        else:
            print(f"{mental_icon} Mental:    {mental_bar} {player.mental:3}/100")

        # Hygiene with shower icon
        hygiene_bar = create_bar(player.hygiene, 100, bar_width)
        hygiene_icon = "🚿" if self.use_colors else "HY"
        hygiene_color = "green" if player.hygiene > 60 else "yellow" if player.hygiene > 30 else "red"
        if self.use_colors:
            print(f"{self.colors['cyan']}║ {self.colors['bold']}{self.colors[hygiene_color]}{hygiene_icon}{self.colors['reset']} Hygiene:   {hygiene_bar} {player.hygiene:3}/100 {self.colors['cyan']}║{self.colors['reset']}")
        else:
            print(f"{hygiene_icon} Hygiene:   {hygiene_bar} {player.hygiene:3}/100")

        # Money with dollar icon
        money_str = f"${player.money:.2f}"
        if self.use_colors:
            money_padding = ' ' * (bar_width + 8 - len(money_str))
            print(f"{self.colors['cyan']}║ {self.colors['bold']}${self.colors['reset']} Money:     {self.colors['green']}{money_str}{self.colors['reset']}{money_padding} {self.colors['cyan']}║{self.colors['reset']}")
        else:
            print(f"$ Money:     {money_str}")

        # Progress indicators for job and housing (if applicable)
        if hasattr(player, 'job_prospects') and hasattr(player, 'housing_prospects') and (player.job_prospects > 0 or player.housing_prospects > 0):
            if self.use_colors:
                print(f"{self.colors['cyan']}╠═══════════════════════════════════════════════════════╣{self.colors['reset']}")
                print(f"{self.colors['cyan']}║ {self.colors['bold']}{self.colors['white']}PROSPECTS{' ' * 42}║{self.colors['reset']}")
            else:
                print("\n=== PROSPECTS ===")

            if player.job_prospects > 0:
                job_bar = create_bar(player.job_prospects, 100, bar_width)
                if self.use_colors:
                    print(f"{self.colors['cyan']}║ {self.colors['bold']}⚒{self.colors['reset']} Job:       {job_bar} {player.job_prospects:3}/100 {self.colors['cyan']}║{self.colors['reset']}")
                else:
                    print(f"⚒ Job:       {job_bar} {player.job_prospects:3}/100")

            if player.housing_prospects > 0:
                house_bar = create_bar(player.housing_prospects, 100, bar_width)
                if self.use_colors:
                    print(f"{self.colors['cyan']}║ {self.colors['bold']}⌂{self.colors['reset']} Housing:   {house_bar} {player.housing_prospects:3}/100 {self.colors['cyan']}║{self.colors['reset']}")
                else:
                    print(f"⌂ Housing:   {house_bar} {player.housing_prospects:3}/100")

        # Skills section (if skills are tracked)
        if hasattr(player, 'skills') and player.skills:
            if self.use_colors:
                print(f"{self.colors['cyan']}╠═══════════════════════════════════════════════════════╣{self.colors['reset']}")
                print(f"{self.colors['cyan']}║ {self.colors['bold']}{self.colors['white']}SKILLS{' ' * 44}║{self.colors['reset']}")
            else:
                print("\n=== SKILLS ===")

            # Show top skills (limit to 3 to save space)
            skills_shown = 0
            for skill_name, skill_level in sorted(player.skills.items(), key=lambda x: x[1], reverse=True):
                if skills_shown >= 3:
                    break
                skill_bar = create_bar(skill_level, 10, bar_width)
                skill_display = skill_name.replace('_', ' ').title()
                # Truncate long skill names
                if len(skill_display) > 10:
                    skill_display = skill_display[:9] + "."
                if self.use_colors:
                    print(f"{self.colors['cyan']}║ {self.colors['bold']}{self.colors['yellow']}•{self.colors['reset']} {skill_display}:{' ' * (10-len(skill_display))} {skill_bar} {skill_level}/10 {self.colors['cyan']}║{self.colors['reset']}")
                else:
                    print(f"• {skill_display}:{' ' * (10-len(skill_display))} {skill_bar} {skill_level}/10")
                skills_shown += 1

        # Bottom of status panel
        if self.use_colors:
            print(f"{self.colors['cyan']}╚═══════════════════════════════════════════════════════╝{self.colors['reset']}")

        # Display recent feedback messages
        if self.feedback_log:
            if self.use_colors:
                print(f"\n{self.colors['bold']}Recent Events:{self.colors['reset']}")
            else:
                print("\n=== RECENT EVENTS ===")
                
            for entry in self.feedback_log:
                if entry["category"] == "success" and self.use_colors:
                    print(f"✓ {self.colors['green']}{entry['message']}{self.colors['reset']}")
                elif entry["category"] == "warning" and self.use_colors:
                    print(f"! {self.colors['yellow']}{entry['message']}{self.colors['reset']}")
                elif self.use_colors:
                    print(f"• {self.colors['white']}{entry['message']}{self.colors['reset']}")
                else:
                    prefix = "✓ " if entry["category"] == "success" else "! " if entry["category"] == "warning" else "• "
                    print(f"{prefix}{entry['message']}")

        # Display weather-specific warnings if conditions are harsh
        if is_harsh:
            if self.use_colors:
                print(f"\n{self.colors['bold']}⚠ WEATHER WARNING ⚠{self.colors['reset']}")
            else:
                print("\n=== WEATHER WARNING ===")
                
            if hasattr(player, 'unlocked_abilities') and not player.unlocked_abilities.get("cold_resistance", False) and temperature < -10:
                if self.use_colors:
                    print(f"{self.colors['red']}Freezing conditions! You need proper shelter or clothing.{self.colors['reset']}")
                else:
                    print("Freezing conditions! You need proper shelter or clothing.")
            elif weather_type == "storm":
                if self.use_colors:
                    print(f"{self.colors['red']}Dangerous storm conditions! Seek shelter immediately.{self.colors['reset']}")
                else:
                    print("Dangerous storm conditions! Seek shelter immediately.")
            elif weather_type == "snow" and temperature < -5:
                if self.use_colors:
                    print(f"{self.colors['yellow']}Heavy snow and cold temperatures. Shelter is important.{self.colors['reset']}")
                else:
                    print("Heavy snow and cold temperatures. Shelter is important.")