"""
Weather visuals module for Hard Times Ottawa.
Provides visual indicators for different weather conditions in the text-based UI.
"""

class WeatherVisuals:
    """Handles generation of visual weather indicators in text UI."""
    
    def __init__(self, use_colors=True):
        """Initialize the weather visuals system.
        
        Args:
            use_colors (bool): Whether to use ANSI color codes
        """
        self.use_colors = use_colors
        
        # Define color codes for weather visuals
        self.colors = {
            "reset": "\033[0m",
            "bold": "\033[1m",
            "blue": "\033[94m",
            "cyan": "\033[96m",
            "green": "\033[92m",
            "yellow": "\033[93m",
            "red": "\033[91m",
            "magenta": "\033[95m",
            "white": "\033[97m",
            "gray": "\033[90m"
        }
        
        # ASCII art for different weather types
        self.weather_art = {
            "clear": [
                "    \\   /    ",
                "     .-.     ",
                "  ― (   ) ―  ",
                "     `-'     ",
                "    /   \\    "
            ],
            "partly_cloudy": [
                "   \\  /      ",
                " _ /\"\".-.    ",
                "   \\_(   ).  ",
                "   /(___(__) ",
                "             "
            ],
            "cloudy": [
                "             ",
                "     .--.    ",
                "  .-(    ).  ",
                " (___.__)__) ",
                "             "
            ],
            "rain": [
                "     .-.     ",
                "    (   ).   ",
                "   (___(__)  ",
                "  ‚'‚'‚'‚'   ",
                "  ‚'‚'‚'‚'   "
            ],
            "snow": [
                "     .-.     ",
                "    (   ).   ",
                "   (___(__)  ",
                "   * * * *   ",
                "  * * * *    "
            ],
            "storm": [
                "     .-.     ",
                "    (   ).   ",
                "   (___(__)  ",
                "  ⚡‚'‚'⚡‚'   ",
                "  ‚'⚡‚'‚'    "
            ],
            "windy": [
                "             ",
                "  ~~~~       ",
                "   ~~~~  ~~  ",
                "  ~~  ~~~~   ",
                " ~~~~  ~~    "
            ],
            "fog": [
                "             ",
                " _ - _ - _ - ",
                "  _ - _ - _  ",
                " _ - _ - _ - ",
                "  _ - _ - _  "
            ]
        }
    
    def get_weather_banner(self, weather_type, temperature, is_harsh=False):
        """Generate a visual weather banner.
        
        Args:
            weather_type (str): Current weather type ("clear", "rain", etc.)
            temperature (float): Current temperature in Celsius
            is_harsh (bool): Whether current weather is harsh
            
        Returns:
            str: ASCII art banner showing weather
        """
        # Map weather type to one of our art templates
        weather_key = self._map_weather_type(weather_type)
        
        # Get ASCII art for this weather
        art = self.weather_art.get(weather_key, self.weather_art["clear"])
        
        # Colorize the art
        colored_art = self._colorize_weather_art(art, weather_key, is_harsh)
        
        # Format temperature
        if self.use_colors:
            temp_color = self._get_temperature_color(temperature)
            temp_display = f"{temp_color}{temperature}°C{self.colors['reset']}"
        else:
            temp_display = f"{temperature}°C"
        
        # Create the final banner with description
        description = self._get_weather_description(weather_key, temperature, is_harsh)
        
        banner = []
        banner.append("┌─────────────────────────────────────┐")
        for i, line in enumerate(colored_art):
            if i == 2:  # Middle line, add temperature
                banner.append(f"│  {line}   {temp_display}   │")
            else:
                banner.append(f"│  {line}            │")
        banner.append("├─────────────────────────────────────┤")
        banner.append(f"│  {description}  │")
        banner.append("└─────────────────────────────────────┘")
        
        return "\n".join(banner)
    
    def _map_weather_type(self, weather_type):
        """Map weather type to one of our art templates.
        
        Args:
            weather_type (str): Weather type string
            
        Returns:
            str: Mapped weather key
        """
        weather_type = weather_type.lower()
        
        if "clear" in weather_type or "sunny" in weather_type:
            return "clear"
        elif "partly" in weather_type and ("cloudy" in weather_type or "cloud" in weather_type):
            return "partly_cloudy"
        elif "cloudy" in weather_type or "overcast" in weather_type:
            return "cloudy"
        elif "rain" in weather_type or "drizzle" in weather_type or "shower" in weather_type:
            return "rain"
        elif "snow" in weather_type or "flurry" in weather_type:
            return "snow"
        elif "storm" in weather_type or "thunder" in weather_type or "lightning" in weather_type:
            return "storm"
        elif "wind" in weather_type or "breezy" in weather_type or "gust" in weather_type:
            return "windy"
        elif "fog" in weather_type or "mist" in weather_type or "haze" in weather_type:
            return "fog"
        else:
            return "cloudy"  # Default
    
    def _colorize_weather_art(self, art, weather_key, is_harsh):
        """Add ANSI color codes to weather art.
        
        Args:
            art (list): ASCII art lines
            weather_key (str): Weather type key
            is_harsh (bool): Whether weather is harsh
            
        Returns:
            list: Colorized ASCII art lines
        """
        if not self.use_colors:
            return art
        
        color_map = {
            "clear": self.colors["yellow"],
            "partly_cloudy": self.colors["white"],
            "cloudy": self.colors["gray"],
            "rain": self.colors["cyan"],
            "snow": self.colors["white"] + self.colors["bold"],
            "storm": self.colors["magenta"],
            "windy": self.colors["cyan"],
            "fog": self.colors["gray"]
        }
        
        # For harsh weather, use more intense colors
        if is_harsh:
            if weather_key == "rain":
                color = self.colors["blue"]
            elif weather_key == "snow":
                color = self.colors["blue"] + self.colors["bold"]
            elif weather_key == "storm":
                color = self.colors["red"]
            elif weather_key == "windy":
                color = self.colors["yellow"]
            else:
                color = color_map.get(weather_key, self.colors["white"])
        else:
            color = color_map.get(weather_key, self.colors["white"])
        
        return [f"{color}{line}{self.colors['reset']}" for line in art]
    
    def _get_weather_description(self, weather_key, temperature, is_harsh):
        """Generate a descriptive text for the current weather.
        
        Args:
            weather_key (str): Weather type key
            temperature (float): Current temperature in Celsius
            is_harsh (bool): Whether weather is harsh
            
        Returns:
            str: Weather description
        """
        descriptions = {
            "clear": "Clear skies, good visibility",
            "partly_cloudy": "Partly cloudy, decent conditions",
            "cloudy": "Overcast skies, limited sunlight",
            "rain": "Rainy conditions, limited shelter options",
            "snow": "Snowy conditions, cold environment",
            "storm": "Stormy weather, dangerous conditions",
            "windy": "Strong winds, potential windchill",
            "fog": "Foggy conditions, limited visibility"
        }
        
        # Generate basic description
        description = descriptions.get(weather_key, "Changing weather conditions")
        
        # Add temperature-specific details
        if temperature < -15:
            temp_desc = "Extremely cold, dangerous exposure"
        elif temperature < -5:
            temp_desc = "Very cold conditions, shelter needed"
        elif temperature < 5:
            temp_desc = "Cold temperature, bundle up"
        elif temperature < 15:
            temp_desc = "Cool temperature, not comfortable"
        elif temperature < 25:
            temp_desc = "Mild temperature, bearable"
        elif temperature < 30:
            temp_desc = "Warm temperature, manageable"
        else:
            temp_desc = "Hot temperature, stay hydrated"
        
        # Format the description
        full_desc = f"{description}. {temp_desc}"
        
        # Colorize if needed
        if self.use_colors:
            if is_harsh:
                return f"{self.colors['red']}{self.colors['bold']}{full_desc}{self.colors['reset']}"
            else:
                return f"{self.colors['white']}{full_desc}{self.colors['reset']}"
        else:
            return full_desc
    
    def _get_temperature_color(self, temperature):
        """Get color for temperature display.
        
        Args:
            temperature (float): Temperature in Celsius
            
        Returns:
            str: ANSI color code
        """
        if temperature < -10:
            return self.colors["blue"] + self.colors["bold"]
        elif temperature < 0:
            return self.colors["blue"]
        elif temperature < 10:
            return self.colors["cyan"]
        elif temperature < 20:
            return self.colors["green"]
        elif temperature < 30:
            return self.colors["yellow"]
        else:
            return self.colors["red"]
    
    def get_temperature_bar(self, temperature):
        """Generate a visual temperature bar.
        
        Args:
            temperature (float): Current temperature in Celsius
            
        Returns:
            str: Visual temperature bar
        """
        # Map temperature to a 0-100 scale (from -30 to +40 Celsius)
        scale_temp = min(max((temperature + 30) / 70 * 100, 0), 100)
        bar_width = 40
        filled_width = int(scale_temp / 100 * bar_width)
        
        if self.use_colors:
            temp_color = self._get_temperature_color(temperature)
            bar = f"Temperature: [{temp_color}"
            
            # Create gradient effect
            for i in range(filled_width):
                # Calculate position in the gradient (0-100)
                pos = i / bar_width * 100
                if pos < 15:  # Cold
                    bar += "■"
                elif pos < 30:  # Cool
                    bar += "■"
                elif pos < 70:  # Moderate
                    bar += "■"
                else:  # Hot
                    bar += "■"
            
            bar += f"{self.colors['reset']}{'-' * (bar_width - filled_width)}] {temperature}°C"
        else:
            bar = f"Temperature: [{'#' * filled_width}{'-' * (bar_width - filled_width)}] {temperature}°C"
        
        return bar
    
    def get_weather_effect_indicator(self, effect_name, effect_value):
        """Generate a visual indicator for a weather effect.
        
        Args:
            effect_name (str): Name of the effect
            effect_value (float): Strength of the effect
            
        Returns:
            str: Visual indicator
        """
        # Normalize effect value to 0-10 scale
        strength = min(max(int(effect_value * 10), 0), 10)
        
        # Format the effect name
        display_name = effect_name.replace('_', ' ').title()
        
        # Abbreviated names for compact display
        name_map = {
            "Wind Chill": "WindChill",
            "Heat Factor": "HeatIndex",
            "Movement Penalty": "Movement",
            "Visibility": "Visibility",
            "Exposure Risk": "Exposure"
        }
        
        display_name = name_map.get(display_name, display_name)
        
        # Generate visual indicator based on strength
        if self.use_colors:
            if strength > 7:
                color = self.colors["red"]
            elif strength > 4:
                color = self.colors["yellow"]
            else:
                color = self.colors["green"]
            
            return f"{display_name}: {color}{'●' * strength}{'○' * (10 - strength)}{self.colors['reset']}"
        else:
            return f"{display_name}: {'#' * strength}{'-' * (10 - strength)}"
    
    def get_weather_effects(self):
        """Return dictionary of possible weather effects and their descriptions.
        
        Returns:
            dict: Weather effects information
        """
        return {
            "wind_chill": {
                "description": "Reduction in perceived temperature due to wind",
                "gameplay_effect": "Increases energy consumption and cold damage"
            },
            "heat_factor": {
                "description": "Increase in perceived temperature due to humidity",
                "gameplay_effect": "Increases hydration needs and heat damage"
            },
            "movement_penalty": {
                "description": "Reduction in movement speed due to weather",
                "gameplay_effect": "Increases travel time and energy consumption"
            },
            "visibility": {
                "description": "Ability to see and navigate",
                "gameplay_effect": "Affects event probabilities and scavenging"
            },
            "exposure_risk": {
                "description": "Risk of health damage from weather exposure",
                "gameplay_effect": "Increases chance of illness and injuries"
            }
        }