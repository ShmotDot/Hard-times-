"""
Game package for Hard Times: Ottawa
A text-based survival game simulating homelessness in Ottawa
"""

# This file intentionally left empty to mark the directory as a Python package
